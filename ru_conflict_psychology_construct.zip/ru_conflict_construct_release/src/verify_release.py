"""Basic release verification checks.

This script checks that no prohibited raw-data files are present and that core
validation tables are readable.
"""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PROHIBITED_EXTENSIONS = {".xlsx", ".xls", ".jsonl", ".parquet", ".pkl", ".pickle"}


def main() -> None:
    prohibited = []
    for path in ROOT.rglob("*"):
        if path.is_file() and path.suffix.lower() in PROHIBITED_EXTENSIONS:
            prohibited.append(path.relative_to(ROOT))
    if prohibited:
        raise RuntimeError("Prohibited raw-data-like files found: " + ", ".join(map(str, prohibited)))

    required = [
        ROOT / "data" / "aggregate" / "corpus_statistics.csv",
        ROOT / "data" / "validation" / "intercoder_agreement_250_segments.csv",
        ROOT / "data" / "validation" / "manual_computational_accuracy_counts.csv",
        ROOT / "docs" / "PRIVACY_AND_ETHICS.md",
    ]
    for file in required:
        if not file.exists():
            raise FileNotFoundError(file)
        if file.suffix == ".csv":
            pd.read_csv(file)
    print("Release verification passed. No raw-data-like files detected.")


if __name__ == "__main__":
    main()
