# Russia Ukraine War Discourse Construct Detection: Reproducibility Release

This repository contains the **shareable, privacy-preserving data and code** for the manuscript:

**Detecting Latent Social Psychological Constructs in Russia Ukraine War Discourse: A Probabilistic and Temporally Validated Analysis of 48,201 Tweets**

The release is designed for reviewer access and public GitHub deposition while respecting platform terms, privacy constraints, and the sensitivity of conflict-related social media data.

## What is included

- Aggregate corpus statistics for the primary and external validation corpora.
- Language distribution of the primary corpus.
- Construct prevalence and co-activation statistics.
- Manual-computational validation counts for the 250-segment validation subset.
- Anonymized inter-coder agreement labels for 250 segment IDs, without tweet text or identifiers.
- Deindividuation ablation robustness results.
- Scripts to recompute precision, recall, F1, absolute agreement, and Cohen's kappa.
- A pipeline skeleton showing how the private raw data were processed without exposing raw tweets.

## What is intentionally excluded

The release does **not** include raw tweet text, tweet IDs, user handles, user-tweet mappings, follower relations, retweet edges, reply edges, or reconstructable network topology. These exclusions are intentional and reflect platform terms and responsible research practice.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python src/compute_intercoder_agreement.py
python src/compute_construct_metrics.py
python src/verify_release.py
```

## Data release level

This is an aggregate and derived-output release. It supports verification of reported validation metrics and corpus-level statistics, but it is not intended to reconstruct the original social media corpus.

## Contact

Corresponding author: research@fahimsufi.com
