"""Run the construct detection pipeline on synthetic, non-identifying demo text."""
from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from theory_construct_pipeline import run_algorithm_1, run_algorithm_3, write_aggregate_outputs


def main():
    df = pd.DataFrame({
        "text": [
            "We stand together with civilians and demand justice now #solidarity",
            "Breaking unconfirmed reports claim missiles are near the city",
            "They always lie and everyone knows the whole story is fake",
            "The government must prepare because the threat is urgent",
            "No major conflict signal is present in this neutral update",
        ],
        "created_at": pd.date_range("2022-02-20", periods=5, freq="D"),
        "retweet_count": [12, 40, 5, 21, 0],
    })

    bundle, detector, outputs = run_algorithm_1(
        df,
        text_col="text",
        time_col="created_at",
        retweet_col="retweet_count",
        labels=None,  # pass a multi-label DataFrame here if human-coded labels exist
    )
    results = run_algorithm_3(df, outputs, time_col="created_at", retweet_col="retweet_count")

    out_dir = ROOT / "demo_outputs"
    write_aggregate_outputs(results, str(out_dir))
    print("Predicted probabilities:")
    print(outputs.probabilities.round(3))
    print(f"\nAggregate outputs written to: {out_dir}")


if __name__ == "__main__":
    main()
