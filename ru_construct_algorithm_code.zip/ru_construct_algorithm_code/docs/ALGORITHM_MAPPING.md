# Algorithm-to-Code Mapping

## Algorithm 1: End-to-end pipeline

Implemented by:

- `FeatureExtractor.fit_transform()`
- `TheoryConstructDetector.fit()`
- `TheoryConstructDetector.predict()`
- `run_algorithm_1()`

Main operations:

- clean records
- identify repeated text
- extract hashtags, language, timestamp, and engagement variables
- generate text representation
- extract theory-aligned lexical indicators
- build multiview feature vector
- infer latent scores and construct probabilities
- return aggregate outputs

## Algorithm 2: Theory-specific probabilistic construct inference

Implemented by:

- `TheoryConstructDetector.fit()`
- `TheoryConstructDetector.predict()`
- `TheoryConstructDetector._latent_scores()`

Main operations:

- estimate posterior probability for each construct
- apply construct-specific thresholds
- output binary construct activations

## Algorithm 3: Validation, robustness, and temporal comparison

Implemented by:

- `compute_prevalence()`
- `compute_coactivation_jaccard()`
- `construct_validation_metrics()`
- `intercoder_agreement()`
- `bootstrap_prevalence_stability()`
- `temporal_trajectories()`
- `cascade_association()`
- `compare_external_temporal()`
- `run_algorithm_3()`

Main operations:

- construct prevalence
- Jaccard co-activation
- manual-computational precision, recall, and F1
- Cohen's kappa for coder agreement
- bootstrap stability
- weekly temporal trajectories
- cascade association diagnostics
- external temporal comparison
