"""
Theory-informed construct detection pipeline for conflict-discourse analysis.

This module implements the three algorithms described in the manuscript:
Algorithm 1: End-to-end construct detection pipeline.
Algorithm 2: Theory-specific probabilistic construct inference.
Algorithm 3: Validation, robustness, and external temporal comparison.

Ethical release note:
- This code does not contain raw tweet text, tweet IDs, user IDs, or network edges.
- It is intended to run locally on data the researcher is permitted to process.
- Public outputs should be limited to aggregate statistics, validation metrics, and
  non-reconstructable summaries.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
import re
import math
import warnings

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_recall_fscore_support, cohen_kappa_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from scipy.special import expit


CONSTRUCTS = [
    "Deindividuation",
    "Cognitive Distortion",
    "Threat Appraisal",
    "Aggression/Deterrence",
    "Rumor Transmission",
]

DEFAULT_THRESHOLDS = {
    "Deindividuation": 0.50,
    "Cognitive Distortion": 0.50,
    "Threat Appraisal": 0.50,
    "Aggression/Deterrence": 0.50,
    "Rumor Transmission": 0.50,
}

DEFAULT_LEXICONS: Dict[str, List[str]] = {
    "Deindividuation": [
        "we", "our", "us", "together", "everyone", "people", "crowd", "army",
        "standwith", "solidarity", "join", "unite", "anonymous", "movement",
    ],
    "Cognitive Distortion": [
        "always", "never", "everyone", "no one", "all", "nothing", "totally",
        "completely", "evil", "fake", "lies", "traitor", "monster", "destroyed",
    ],
    "Threat Appraisal": [
        "threat", "danger", "attack", "invasion", "risk", "urgent", "warning",
        "missile", "bomb", "war", "if", "unless", "prepare", "escalation",
    ],
    "Aggression/Deterrence": [
        "strike", "retaliate", "punish", "destroy", "defeat", "sanction", "weapon",
        "force", "attack", "counterattack", "deterrence", "revenge", "kill",
    ],
    "Rumor Transmission": [
        "breaking", "unconfirmed", "reportedly", "rumor", "claim", "allegedly",
        "sources", "not verified", "developing", "heard", "maybe", "apparently",
    ],
}

MORAL_LEXICONS: Dict[str, List[str]] = {
    "care": ["harm", "suffer", "civilian", "victim", "protect", "safe", "help"],
    "fairness": ["justice", "rights", "fair", "law", "accountability", "illegal"],
    "loyalty": ["nation", "ally", "solidarity", "betray", "patriot", "together"],
    "authority": ["government", "leader", "state", "military", "order", "command"],
    "sanctity": ["sacred", "pure", "holy", "desecrate", "evil", "corrupt"],
}


def clean_text(text: object) -> str:
    """Normalize text without retaining personally identifying metadata."""
    if pd.isna(text):
        return ""
    text = str(text)
    text = re.sub(r"https?://\S+", " URL ", text)
    text = re.sub(r"@\w+", " USER ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def extract_hashtags(text: str) -> List[str]:
    return [h.lower() for h in re.findall(r"#\w+", text or "")]


def lexicon_count(text: str, terms: Iterable[str]) -> int:
    """Count high-precision lexical cue hits using word-boundary matching where possible."""
    text_l = f" {text.lower()} "
    count = 0
    for term in terms:
        term_l = term.lower()
        if " " in term_l:
            count += int(term_l in text_l)
        else:
            count += len(re.findall(rf"\b{re.escape(term_l)}\b", text_l))
    return count


def moral_proportions(text: str, moral_lexicons: Mapping[str, List[str]] = MORAL_LEXICONS) -> Dict[str, float]:
    counts = {k: lexicon_count(text, v) for k, v in moral_lexicons.items()}
    total = sum(counts.values())
    if total == 0:
        return {k: 0.0 for k in moral_lexicons}
    return {k: v / total for k, v in counts.items()}


def shannon_entropy(items: Sequence[str]) -> float:
    if not items:
        return 0.0
    values, counts = np.unique(items, return_counts=True)
    probs = counts / counts.sum()
    return float(-(probs * np.log2(probs)).sum())


def herfindahl_concentration(items: Sequence[str]) -> float:
    if not items:
        return 0.0
    values, counts = np.unique(items, return_counts=True)
    probs = counts / counts.sum()
    return float((probs ** 2).sum())


@dataclass
class FeatureConfig:
    text_col: str = "text"
    time_col: Optional[str] = "created_at"
    retweet_col: Optional[str] = "retweet_count"
    language_col: Optional[str] = "language"
    max_tfidf_features: int = 512
    min_df: int = 2


@dataclass
class FeatureBundle:
    df: pd.DataFrame
    texts: List[str]
    tfidf_matrix: object
    numeric_features: pd.DataFrame
    feature_names: List[str]
    vectorizer: TfidfVectorizer


class FeatureExtractor:
    """
    Implements the feature-construction part of Algorithm 1.

    It extracts cleaned text, lexical cues, moral proportions, temporal variables,
    engagement variables, hashtag concentration, and a TF-IDF representation.
    A BERTweet embedding layer can be swapped in for TF-IDF in local experiments.
    """

    def __init__(self, config: FeatureConfig = FeatureConfig(), lexicons: Optional[Dict[str, List[str]]] = None):
        self.config = config
        self.lexicons = lexicons or DEFAULT_LEXICONS
        self.vectorizer: Optional[TfidfVectorizer] = None

    def fit_transform(self, df: pd.DataFrame) -> FeatureBundle:
        df2 = self._prepare_dataframe(df)
        texts = df2["clean_text"].tolist()
        self.vectorizer = TfidfVectorizer(
            max_features=self.config.max_tfidf_features,
            min_df=self.config.min_df,
            ngram_range=(1, 2),
            lowercase=True,
        )
        tfidf = self.vectorizer.fit_transform(texts)
        numeric = self._numeric_features(df2)
        return FeatureBundle(df2, texts, tfidf, numeric, list(numeric.columns), self.vectorizer)

    def transform(self, df: pd.DataFrame) -> FeatureBundle:
        if self.vectorizer is None:
            raise RuntimeError("FeatureExtractor must be fitted before transform().")
        df2 = self._prepare_dataframe(df)
        texts = df2["clean_text"].tolist()
        tfidf = self.vectorizer.transform(texts)
        numeric = self._numeric_features(df2)
        return FeatureBundle(df2, texts, tfidf, numeric, list(numeric.columns), self.vectorizer)

    def _prepare_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        cfg = self.config
        if cfg.text_col not in df.columns:
            raise ValueError(f"Missing text column: {cfg.text_col}")
        out = df.copy()
        out["clean_text"] = out[cfg.text_col].map(clean_text)
        out = out[out["clean_text"].str.len() > 0].copy()
        out["text_hash"] = pd.util.hash_pandas_object(out["clean_text"], index=False).astype(str)
        out["is_repeated_text"] = out.duplicated("clean_text", keep=False).astype(int)
        out["hashtags"] = out["clean_text"].map(extract_hashtags)
        return out

    def _numeric_features(self, df: pd.DataFrame) -> pd.DataFrame:
        cfg = self.config
        rows = []
        for _, row in df.iterrows():
            text = row["clean_text"]
            hashtags = row["hashtags"]
            d = {
                "char_len": len(text),
                "word_len": len(text.split()),
                "hashtag_count": len(hashtags),
                "hashtag_uniformity": herfindahl_concentration(hashtags),
                "hashtag_entropy": shannon_entropy(hashtags),
                "is_repeated_text": int(row.get("is_repeated_text", 0)),
            }
            if cfg.retweet_col and cfg.retweet_col in df.columns:
                try:
                    d["log_retweets"] = math.log1p(float(row[cfg.retweet_col]))
                except Exception:
                    d["log_retweets"] = 0.0
            else:
                d["log_retweets"] = 0.0
            if cfg.time_col and cfg.time_col in df.columns:
                ts = pd.to_datetime(row[cfg.time_col], errors="coerce")
                d["hour"] = 0 if pd.isna(ts) else ts.hour
                d["dayofweek"] = 0 if pd.isna(ts) else ts.dayofweek
            else:
                d["hour"] = 0
                d["dayofweek"] = 0
            for construct, terms in self.lexicons.items():
                d[f"lex_{construct}"] = lexicon_count(text, terms)
            for moral, terms in MORAL_LEXICONS.items():
                d[f"moral_{moral}"] = moral_proportions(text)[moral]
            rows.append(d)
        return pd.DataFrame(rows).fillna(0.0)


@dataclass
class ConstructOutputs:
    probabilities: pd.DataFrame
    predictions: pd.DataFrame
    latent_scores: pd.DataFrame
    moral_scores: pd.DataFrame


class TheoryConstructDetector:
    """
    Implements Algorithm 2: theory-specific probabilistic construct inference.

    If human labels are supplied, the detector trains one binary logistic model per construct.
    If labels are not supplied, it trains weak-supervision models using high-precision
    lexicon cues. This is suitable for reproducibility demos, but a paper should report
    manual validation metrics where available.
    """

    def __init__(self, constructs: Sequence[str] = CONSTRUCTS, thresholds: Optional[Dict[str, float]] = None):
        self.constructs = list(constructs)
        self.thresholds = thresholds or DEFAULT_THRESHOLDS.copy()
        self.models: Dict[str, Pipeline] = {}
        self.feature_columns_: Optional[List[str]] = None

    def fit(self, bundle: FeatureBundle, labels: Optional[pd.DataFrame] = None) -> "TheoryConstructDetector":
        X = self._combine_features(bundle)
        self.feature_columns_ = list(X.columns)
        for construct in self.constructs:
            if labels is not None and construct in labels.columns:
                y = labels[construct].astype(int).values
            else:
                cue_col = f"lex_{construct}"
                y = (bundle.numeric_features[cue_col].values > 0).astype(int)
                if y.sum() == 0:
                    warnings.warn(f"No weak positive labels found for {construct}; using all-zero fallback.")
                    y = np.zeros(len(X), dtype=int)
            if len(np.unique(y)) < 2:
                self.models[construct] = _ConstantProbModel(prob=float(y.mean()))
            else:
                self.models[construct] = Pipeline([
                    ("scaler", StandardScaler(with_mean=False)),
                    ("clf", LogisticRegression(max_iter=500, class_weight="balanced", solver="liblinear")),
                ])
                self.models[construct].fit(X, y)
        return self

    def predict(self, bundle: FeatureBundle) -> ConstructOutputs:
        X = self._combine_features(bundle)
        if self.feature_columns_ is not None:
            for col in self.feature_columns_:
                if col not in X.columns:
                    X[col] = 0.0
            X = X[self.feature_columns_]
        probs = {}
        preds = {}
        for construct, model in self.models.items():
            if hasattr(model, "predict_proba"):
                p = model.predict_proba(X)[:, 1]
            else:
                p = model.predict_proba(X)
            probs[construct] = p
            preds[construct] = (p >= self.thresholds.get(construct, 0.5)).astype(int)
        prob_df = pd.DataFrame(probs, index=bundle.df.index)
        pred_df = pd.DataFrame(preds, index=bundle.df.index)
        latent = self._latent_scores(bundle, prob_df)
        moral = bundle.numeric_features[[c for c in bundle.numeric_features.columns if c.startswith("moral_")]].copy()
        return ConstructOutputs(prob_df, pred_df, latent, moral)

    def _combine_features(self, bundle: FeatureBundle) -> pd.DataFrame:
        # Convert sparse TF-IDF to a compact DataFrame. For large corpora, keep sparse matrices
        # and use scipy.sparse.hstack in production.
        tfidf_arr = bundle.tfidf_matrix.toarray()
        tfidf_cols = [f"tfidf_{i}" for i in range(tfidf_arr.shape[1])]
        tfidf_df = pd.DataFrame(tfidf_arr, columns=tfidf_cols, index=bundle.numeric_features.index)
        return pd.concat([bundle.numeric_features.reset_index(drop=True), tfidf_df.reset_index(drop=True)], axis=1)

    def _latent_scores(self, bundle: FeatureBundle, prob_df: pd.DataFrame) -> pd.DataFrame:
        nf = bundle.numeric_features.reset_index(drop=True)
        out = pd.DataFrame(index=nf.index)
        out["H_t_hostility"] = np.clip(nf.get("lex_Aggression/Deterrence", 0) + 0.5 * prob_df.get("Aggression/Deterrence", 0).values, 0, None)
        out["DI_t_deindividuation"] = np.clip(
            nf.get("lex_Deindividuation", 0) + nf.get("hashtag_uniformity", 0) + nf.get("is_repeated_text", 0), 0, None
        )
        out["MRS_t_mobilization_readiness"] = np.clip(nf.get("hashtag_count", 0) + nf.get("log_retweets", 0), 0, None)
        out["THR_t_threat"] = np.clip(nf.get("lex_Threat Appraisal", 0) + 0.5 * prob_df.get("Threat Appraisal", 0).values, 0, None)
        return out


class _ConstantProbModel:
    def __init__(self, prob: float):
        self.prob = float(prob)

    def predict_proba(self, X):
        p1 = np.full(len(X), self.prob)
        return np.column_stack([1.0 - p1, p1])


def run_algorithm_1(
    df: pd.DataFrame,
    text_col: str = "text",
    time_col: Optional[str] = "created_at",
    retweet_col: Optional[str] = "retweet_count",
    labels: Optional[pd.DataFrame] = None,
) -> Tuple[FeatureBundle, TheoryConstructDetector, ConstructOutputs]:
    """End-to-end implementation of Algorithm 1."""
    extractor = FeatureExtractor(FeatureConfig(text_col=text_col, time_col=time_col, retweet_col=retweet_col))
    bundle = extractor.fit_transform(df)
    detector = TheoryConstructDetector().fit(bundle, labels=labels)
    outputs = detector.predict(bundle)
    return bundle, detector, outputs


def compute_prevalence(predictions: pd.DataFrame) -> pd.DataFrame:
    n = len(predictions)
    rows = []
    for c in predictions.columns:
        count = int(predictions[c].sum())
        rows.append({"construct": c, "count": count, "percentage": 100 * count / max(n, 1)})
    return pd.DataFrame(rows)


def compute_coactivation_jaccard(predictions: pd.DataFrame) -> pd.DataFrame:
    rows = []
    cols = list(predictions.columns)
    for a in cols:
        for b in cols:
            A = predictions[a].astype(bool).values
            B = predictions[b].astype(bool).values
            inter = int(np.logical_and(A, B).sum())
            union = int(np.logical_or(A, B).sum())
            rows.append({"construct_a": a, "construct_b": b, "count": inter, "jaccard": inter / union if union else 0.0})
    return pd.DataFrame(rows)


def construct_validation_metrics(y_true: pd.DataFrame, y_pred: pd.DataFrame) -> pd.DataFrame:
    """One-versus-rest construct validation metrics for multi-label annotation."""
    rows = []
    common = [c for c in y_true.columns if c in y_pred.columns]
    for c in common:
        yt = y_true[c].astype(int).values
        yp = y_pred[c].astype(int).values
        tp = int(((yt == 1) & (yp == 1)).sum())
        fp = int(((yt == 0) & (yp == 1)).sum())
        fn = int(((yt == 1) & (yp == 0)).sum())
        precision = tp / (tp + fp) if (tp + fp) else 0.0
        recall = tp / (tp + fn) if (tp + fn) else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
        rows.append({
            "construct": c, "TP": tp, "FP": fp, "FN": fn,
            "precision": precision, "recall": recall, "f1": f1,
        })
    out = pd.DataFrame(rows)
    if not out.empty:
        out.loc[len(out)] = {
            "construct": "Macro Average",
            "TP": np.nan, "FP": np.nan, "FN": np.nan,
            "precision": out["precision"].mean(),
            "recall": out["recall"].mean(),
            "f1": out["f1"].mean(),
        }
    return out


def intercoder_agreement(rater1: Sequence[int], rater2: Sequence[int]) -> Dict[str, float]:
    r1 = np.asarray(rater1).astype(int)
    r2 = np.asarray(rater2).astype(int)
    if len(r1) != len(r2):
        raise ValueError("Rater arrays must have the same length.")
    agreement = float((r1 == r2).mean())
    return {
        "n": int(len(r1)),
        "absolute_agreement": agreement,
        "cohen_kappa": float(cohen_kappa_score(r1, r2)),
        "agreements": int((r1 == r2).sum()),
        "disagreements": int((r1 != r2).sum()),
    }


def bootstrap_prevalence_stability(predictions: pd.DataFrame, n_boot: int = 500, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    n = len(predictions)
    for c in predictions.columns:
        vals = []
        arr = predictions[c].astype(int).values
        for _ in range(n_boot):
            idx = rng.integers(0, n, size=n)
            vals.append(arr[idx].mean())
        rows.append({
            "construct": c,
            "mean_prevalence": float(np.mean(vals)),
            "ci_low": float(np.quantile(vals, 0.025)),
            "ci_high": float(np.quantile(vals, 0.975)),
            "bootstrap_stability": float(1 - np.std(vals)),
        })
    return pd.DataFrame(rows)


def temporal_trajectories(df: pd.DataFrame, predictions: pd.DataFrame, time_col: str = "created_at", freq: str = "W") -> pd.DataFrame:
    if time_col not in df.columns:
        raise ValueError(f"Missing time column: {time_col}")
    tmp = predictions.copy()
    tmp[time_col] = pd.to_datetime(df.loc[predictions.index, time_col], errors="coerce")
    tmp = tmp.dropna(subset=[time_col])
    if tmp.empty:
        return pd.DataFrame()
    grouped = tmp.set_index(time_col).groupby(pd.Grouper(freq=freq))[predictions.columns].sum()
    return grouped.reset_index()


def cascade_association(df: pd.DataFrame, predictions: pd.DataFrame, retweet_col: str = "retweet_count") -> pd.DataFrame:
    if retweet_col not in df.columns:
        raise ValueError(f"Missing retweet column: {retweet_col}")
    retweets = pd.to_numeric(df.loc[predictions.index, retweet_col], errors="coerce").fillna(0)
    rows = []
    for c in predictions.columns:
        active = predictions[c].astype(bool).values
        rows.append({
            "construct": c,
            "mean_retweets_active": float(retweets[active].mean()) if active.any() else 0.0,
            "mean_retweets_inactive": float(retweets[~active].mean()) if (~active).any() else 0.0,
            "median_retweets_active": float(retweets[active].median()) if active.any() else 0.0,
            "n_active": int(active.sum()),
        })
    return pd.DataFrame(rows)


def compare_external_temporal(primary_prev: pd.DataFrame, external_prev: pd.DataFrame) -> pd.DataFrame:
    """Compare construct prevalence between primary and external validation corpora."""
    p = primary_prev.rename(columns={"count": "primary_count", "percentage": "primary_percentage"})
    e = external_prev.rename(columns={"count": "external_count", "percentage": "external_percentage"})
    out = p.merge(e, on="construct", how="outer").fillna(0)
    out["percentage_change"] = out["external_percentage"] - out["primary_percentage"]
    out["interpretation"] = np.where(
        out["percentage_change"].abs() < 1.0,
        "stable",
        np.where(out["percentage_change"] > 0, "higher in external corpus", "attenuated in external corpus"),
    )
    return out


def run_algorithm_3(
    df: pd.DataFrame,
    outputs: ConstructOutputs,
    time_col: str = "created_at",
    retweet_col: str = "retweet_count",
    human_labels: Optional[pd.DataFrame] = None,
    coder1: Optional[Sequence[int]] = None,
    coder2: Optional[Sequence[int]] = None,
) -> Dict[str, pd.DataFrame | Dict[str, float]]:
    """Validation, robustness, and temporal diagnostics for Algorithm 3."""
    results: Dict[str, pd.DataFrame | Dict[str, float]] = {
        "prevalence": compute_prevalence(outputs.predictions),
        "coactivation_jaccard": compute_coactivation_jaccard(outputs.predictions),
        "bootstrap_stability": bootstrap_prevalence_stability(outputs.predictions),
    }
    if time_col in df.columns:
        results["temporal_trajectories"] = temporal_trajectories(df, outputs.predictions, time_col=time_col)
    if retweet_col in df.columns:
        results["cascade_association"] = cascade_association(df, outputs.predictions, retweet_col=retweet_col)
    if human_labels is not None:
        common_idx = human_labels.index.intersection(outputs.predictions.index)
        results["manual_computational_metrics"] = construct_validation_metrics(
            human_labels.loc[common_idx], outputs.predictions.loc[common_idx]
        )
    if coder1 is not None and coder2 is not None:
        results["intercoder_agreement"] = intercoder_agreement(coder1, coder2)
    return results


def write_aggregate_outputs(results: Mapping[str, object], output_dir: str) -> None:
    """Write only aggregate, non-reconstructable outputs."""
    import os
    os.makedirs(output_dir, exist_ok=True)
    for name, obj in results.items():
        if isinstance(obj, pd.DataFrame):
            obj.to_csv(os.path.join(output_dir, f"{name}.csv"), index=False)
        elif isinstance(obj, dict):
            pd.DataFrame([obj]).to_csv(os.path.join(output_dir, f"{name}.csv"), index=False)
