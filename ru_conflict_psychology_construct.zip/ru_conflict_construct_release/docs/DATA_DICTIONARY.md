# Data Dictionary

## data/aggregate/corpus_statistics.csv
Corpus-level statistics. No raw tweet text or identifiers are included.

## data/aggregate/language_distribution_primary.csv
Language counts and percentages for the primary corpus.

## data/aggregate/construct_prevalence_primary.csv
Prevalence counts and percentages for the top five detected constructs in the primary corpus.

## data/aggregate/construct_coactivation_jaccard_long.csv
Long-format co-activation matrix. Each row gives a pair of constructs, co-occurrence count, and Jaccard index.

## data/aggregate/external_temporal_validation_summary.csv
High-level comparison between the primary corpus and external temporal validation corpus.

## data/aggregate/baseline_comparison_summary.csv
Summary of baseline comparison metrics reported in the manuscript.

## data/validation/intercoder_agreement_250_segments.csv
Anonymized coder labels for 250 validation segments. Columns: Segment_ID, Coder_A, Coder_B, Agreement. No tweet text, tweet IDs, or user identifiers are included.

## data/validation/intercoder_agreement_summary.csv
Aggregate inter-coder agreement statistics.

## data/validation/manual_computational_accuracy_counts.csv
Construct-level true positives, false positives, false negatives, and computed precision, recall, and F1 values for the 250-segment validation subset.

## data/validation/ablation_deindividuation.csv
Ablation results showing deindividuation detection under reduced feature configurations.
