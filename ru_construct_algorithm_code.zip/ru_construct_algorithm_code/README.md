# Theory-Informed Construct Detection Code

This repository contains a reproducible reference implementation of the three algorithms in the manuscript:

1. **Algorithm 1:** End-to-end pipeline for theory-informed social media construct detection.
2. **Algorithm 2:** Theory-specific probabilistic construct inference.
3. **Algorithm 3:** Validation, robustness, and external temporal comparison.

## Ethical data release position

This code does not include raw tweets, tweet IDs, usernames, user-tweet mappings, retweet/reply edges, follower relations, or reconstructable graph topology. It is intended to be run locally on data that the researcher is permitted to process. Public outputs should be restricted to aggregate statistics, construct counts, validation metrics, and non-reconstructable summaries.

## Install

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
```

## Run synthetic demo

```bash
python examples/run_synthetic_demo.py
```

## Run on local data

Your local CSV should include a text column and may include timestamp and retweet-count columns.

```bash
python examples/run_local_csv.py \
  --input local_private_tweets.csv \
  --text-col text \
  --time-col created_at \
  --retweet-col retweet_count \
  --output outputs
```

If the CSV includes manually adjudicated construct labels with the following column names, the script will compute construct-level validation metrics:

- `Deindividuation`
- `Cognitive Distortion`
- `Threat Appraisal`
- `Aggression/Deterrence`
- `Rumor Transmission`

## Main outputs

The pipeline writes aggregate CSV files only, including:

- construct prevalence
- co-activation Jaccard scores
- bootstrap prevalence stability
- temporal trajectories, if timestamps are available
- cascade association summaries, if retweet counts are available
- manual-computational validation metrics, if labels are available

## Note on BERTweet

The default implementation uses TF-IDF features for a lightweight reproducibility demonstration. For full local experiments, the `FeatureExtractor` can be extended to replace TF-IDF vectors with BERTweet embeddings. The rest of the pipeline remains the same: embeddings are combined with lexical, temporal, engagement, and graph-derived indicators before probabilistic construct inference.
