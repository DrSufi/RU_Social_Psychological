"""
Run the pipeline on a local CSV file.

Required column: text
Optional columns: created_at, retweet_count
Optional label columns for supervised validation:
Deindividuation, Cognitive Distortion, Threat Appraisal,
Aggression/Deterrence, Rumor Transmission
"""
from pathlib import Path
import argparse
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from theory_construct_pipeline import CONSTRUCTS, run_algorithm_1, run_algorithm_3, write_aggregate_outputs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Local CSV file path")
    parser.add_argument("--output", default="outputs", help="Output directory for aggregate CSV files")
    parser.add_argument("--text-col", default="text")
    parser.add_argument("--time-col", default="created_at")
    parser.add_argument("--retweet-col", default="retweet_count")
    args = parser.parse_args()

    df = pd.read_csv(args.input)
    label_cols = [c for c in CONSTRUCTS if c in df.columns]
    labels = df[label_cols].copy() if label_cols else None

    bundle, detector, outputs = run_algorithm_1(
        df,
        text_col=args.text_col,
        time_col=args.time_col if args.time_col in df.columns else None,
        retweet_col=args.retweet_col if args.retweet_col in df.columns else None,
        labels=labels,
    )
    results = run_algorithm_3(
        bundle.df,
        outputs,
        time_col=args.time_col if args.time_col in bundle.df.columns else "created_at",
        retweet_col=args.retweet_col if args.retweet_col in bundle.df.columns else "retweet_count",
        human_labels=labels,
    )
    write_aggregate_outputs(results, args.output)
    print(f"Aggregate outputs written to {args.output}")


if __name__ == "__main__":
    main()
