"""Recompute precision, recall, and F1 from manual-computational validation counts."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data" / "validation" / "manual_computational_accuracy_counts.csv"


def safe_div(num: float, den: float) -> float:
    return 0.0 if den == 0 else num / den


def main() -> None:
    df = pd.read_csv(INPUT)
    rows = []
    for _, r in df.iterrows():
        tp = float(r["true_positives"])
        fp = float(r["false_positives"])
        fn = float(r["false_negatives"])
        precision = safe_div(tp, tp + fp)
        recall = safe_div(tp, tp + fn)
        f1 = safe_div(2 * precision * recall, precision + recall)
        rows.append({
            "latent_construct": r["latent_construct"],
            "precision": precision,
            "recall": recall,
            "f1_score": f1,
        })
    out = pd.DataFrame(rows)
    print(out.to_string(index=False, formatters={
        "precision": "{:.4f}".format,
        "recall": "{:.4f}".format,
        "f1_score": "{:.4f}".format,
    }))
    print("\nMacro averages:")
    print(f"Precision: {out['precision'].mean():.4f}")
    print(f"Recall: {out['recall'].mean():.4f}")
    print(f"F1: {out['f1_score'].mean():.4f}")


if __name__ == "__main__":
    main()
