# Note for Reviewer 2

This repository provides a shareable reproducibility package for the manuscript while respecting ethical and platform constraints.

Reviewer concern: methodology and lexicon construction should be more reproducible.

Response in this release:

1. `src/pipeline_skeleton.py` documents the reproducible pipeline structure used in the manuscript.
2. `data/validation/manual_computational_accuracy_counts.csv` provides construct-level validation counts for the manually validated 250-segment subset.
3. `data/validation/intercoder_agreement_250_segments.csv` provides anonymized coder agreement data without tweet text or identifiers.
4. `src/compute_intercoder_agreement.py` recomputes absolute agreement and Cohen's kappa.
5. `src/compute_construct_metrics.py` recomputes precision, recall, and F1 from the validation counts.
6. `data/validation/ablation_deindividuation.csv` supports the ablation robustness claim that detection was not reducible to direct dictionary recovery.

Raw tweet text and user-level network data are not released because they are sensitive and potentially reconstructable.
