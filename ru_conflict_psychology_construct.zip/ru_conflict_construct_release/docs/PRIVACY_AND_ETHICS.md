# Privacy and Ethics Note

This repository is structured to support reproducibility without exposing sensitive or reconstructable social media data.

## Excluded data

The following are not included:

- Raw tweet text
- Tweet identifiers
- User handles or user IDs
- User-to-tweet mappings
- Follower relationships
- Retweet edges
- Reply edges
- Reconstructable graph topology

## Included data

The included files contain aggregate statistics, validation counts, anonymized segment-level coder labels, and derived model evaluation outputs. Segment IDs such as `SEG_001` are local non-reconstructable labels and cannot be mapped back to tweet IDs or user accounts from this release.

## Intended use

This release is intended for manuscript review, reproducibility checking, and methodological transparency. It should not be used for individual profiling, surveillance, moderation, risk labeling, or identification of users or communities.
