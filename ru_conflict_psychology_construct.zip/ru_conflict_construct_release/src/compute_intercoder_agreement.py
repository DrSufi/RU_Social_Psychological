"""Compute inter-coder agreement for the anonymized validation subset.

The input file contains only local segment IDs and binary coder labels. It does not
contain tweet text, tweet IDs, user handles, or reconstructable identifiers.
"""
from pathlib import Path
import pandas as pd
from sklearn.metrics import cohen_kappa_score

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data" / "validation" / "intercoder_agreement_250_segments.csv"


def main() -> None:
    df = pd.read_csv(INPUT)
    required = {"Segment_ID", "Coder_A", "Coder_B", "Agreement"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    n = len(df)
    agreements = int((df["Coder_A"] == df["Coder_B"]).sum())
    absolute_agreement = agreements / n
    kappa = cohen_kappa_score(df["Coder_A"], df["Coder_B"])

    print(f"Segments: {n}")
    print(f"Agreements: {agreements}")
    print(f"Disagreements: {n - agreements}")
    print(f"Absolute agreement: {absolute_agreement:.4f} ({absolute_agreement*100:.2f}%)")
    print(f"Cohen's kappa: {kappa:.4f}")


if __name__ == "__main__":
    main()
